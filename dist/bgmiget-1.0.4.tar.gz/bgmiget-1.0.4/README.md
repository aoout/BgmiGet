# BgmiGet

## How to Install

```
pip install bgmiget
```

## Basic Usage

Search anime by "search" commnad.

```
bgmiget search '因为太怕痛' 7 "sc" "桜都字幕组"
>0  -> 【因为太怕痛...】【07】【桜都字幕组】
```

Then, download anime by index.

```
bgmiget download 0
```

Subscribe anime by "subscribe" command, and list them by "show_subscribed" command.

At last, check for updates on anime by "upgrade" command.

